-- Galo Studio: local Luau testing helper (Roblox Studio plugin)
-- Creates ordinary server scripts. No injection, HTTP bridge, or external requests.
local ServerScriptService = game:GetService("ServerScriptService")
local Selection = game:GetService("Selection")
local toolbar = plugin:CreateToolbar("Galo Studio")
local toggle = toolbar:CreateButton("Galo Studio", "Open the Luau test panel", "")
local widgetInfo = DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Right, false, false, 430, 350, 300, 250)
local widget = plugin:CreateDockWidgetPluginGui("GaloStudioLuauPanel", widgetInfo)
widget.Title = "Galo Studio | Luau Tests"
local root = Instance.new("Frame")
root.BackgroundColor3 = Color3.fromRGB(22, 22, 25)
root.Size = UDim2.fromScale(1, 1)
root.Parent = widget
local pad = Instance.new("UIPadding")
pad.PaddingTop = UDim.new(0, 12)
pad.PaddingLeft = UDim.new(0, 12)
pad.PaddingRight = UDim.new(0, 12)
pad.PaddingBottom = UDim.new(0, 12)
pad.Parent = root
local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 8)
layout.SortOrder = Enum.SortOrder.LayoutOrder
layout.Parent = root
local function label(text, height)
    local item = Instance.new("TextLabel")
    item.Size = UDim2.new(1, 0, 0, height)
    item.BackgroundTransparency = 1
    item.Text = text
    item.TextColor3 = Color3.fromRGB(235, 235, 240)
    item.TextXAlignment = Enum.TextXAlignment.Left
    item.TextWrapped = true
    item.Font = Enum.Font.Gotham
    item.TextSize = 13
    item.Parent = root
    return item
end
label("GALO STUDIO  /  LUAU", 25)
local editor = Instance.new("TextBox")
editor.Size = UDim2.new(1, 0, 1, -140)
editor.BackgroundColor3 = Color3.fromRGB(35, 35, 40)
editor.TextColor3 = Color3.fromRGB(235, 235, 240)
editor.PlaceholderColor3 = Color3.fromRGB(145, 145, 150)
editor.Font = Enum.Font.Code
editor.TextSize = 14
editor.MultiLine = true
editor.ClearTextOnFocus = false
editor.TextXAlignment = Enum.TextXAlignment.Left
editor.TextYAlignment = Enum.TextYAlignment.Top
editor.Text = 'print("Galo Studio test OK")'
editor.Parent = root
local button = Instance.new("TextButton")
button.Size = UDim2.new(1, 0, 0, 35)
button.BackgroundColor3 = Color3.fromRGB(235, 235, 240)
button.TextColor3 = Color3.fromRGB(20, 20, 22)
button.Text = "CREATE TEST SCRIPT"
button.Font = Enum.Font.GothamBold
button.TextSize = 13
button.Parent = root
local status = label("Creates a Script in ServerScriptService. Press Play to run.", 30)
button.Activated:Connect(function()
    if editor.Text:match("^%s*$") then
        status.Text = "Enter Luau code first."
        return
    end
    local scriptObject = Instance.new("Script")
    scriptObject.Name = "GaloStudioTest"
    scriptObject.Enabled = false
    local ok, err = pcall(function()
        scriptObject.Source = editor.Text
        scriptObject.Parent = ServerScriptService
    end)
    if not ok then
        scriptObject:Destroy()
        status.Text = "Cannot create script: " .. tostring(err)
        return
    end
    Selection:Set({scriptObject})
    plugin:OpenScript(scriptObject)
    status.Text = "Script created disabled. Review, enable it, then press Play."
end)
toggle.Click:Connect(function() widget.Enabled = not widget.Enabled end)
