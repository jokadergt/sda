# Galo Studio — Luau test plugin

1. Open Roblox Studio and your own test place.
2. In Studio, create a new local plugin from `GaloStudio.plugin.lua` using the Studio plugin workflow, or paste its source into a local plugin script and save as a plugin.
3. Open the **Galo Studio** toolbar button.
4. Type Luau code and click **CREATE TEST SCRIPT**.
5. The created Script is **disabled by default**. Inspect it, enable it in Properties, then press **Play**.
6. Read test output/errors in **View → Output**.

This is a Studio-native testing mode, not an injector. It tests Roblox-supported Luau APIs; it does not implement executor-only UNC APIs or attach the Windows DLL to Studio.

The plugin does not use HTTP, load remote scripts, or request process access. The source package's Windows components have not been compiled or validated by this addition.
