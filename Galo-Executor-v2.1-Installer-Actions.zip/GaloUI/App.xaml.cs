﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace GaloUI
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{

	}

}
