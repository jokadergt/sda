using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace GaloUI
{
	public partial class ClientsWindow : Window
	{
		public string GaloVersion = "1.0.8";
		private const string SupportedVersion = "1.0.8";

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
		public struct ClientInfo
		{
			public string version;
			public string name;
			public int id;
		}

		[DllImport("Galo.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern void Initialize();

		[DllImport("Galo.dll", CallingConvention = CallingConvention.Cdecl)]
		private static extern IntPtr GetClients();

		[DllImport("Galo.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		private static extern void Execute(byte[] scriptSource, string[] clientUsers, int numUsers);

		[DllImport("Galo.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		private static extern IntPtr Compilable(byte[] scriptSource);

		private readonly DispatcherTimer _timer;
		private DateTime _lastExecution = DateTime.MinValue;
		private readonly HashSet<int> _warnedPids = new();
		private readonly HashSet<int> _incompatiblePids = new();
		private static readonly TimeSpan ExecutionCooldown = TimeSpan.FromMilliseconds(350);
		private static void LogSafety(string message)
		{
			System.Diagnostics.Trace.WriteLine($"[Galo Safety] {DateTime.UtcNow:O} {message}");
		}
		public List<ClientInfo> ActiveClients { get; private set; } = new();

		// Remote compatibility checks removed; no upstream version server is contacted.

		public ClientsWindow()
		{
			InitializeComponent();
			Initialize();
			MouseLeftButtonDown += (_, _) => DragMove();

			_timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(750) };
			_timer.Tick += UpdateClientList;
			_timer.Start();
		}


		private void UpdateClientList(object sender, EventArgs e)
		{
			Dictionary<int, ClientInfo> newClients;
			try { newClients = GetClientsFromDll().Where(c => c.id > 0 && !string.IsNullOrWhiteSpace(c.name)).GroupBy(c => c.id).ToDictionary(g => g.Key, g => g.First()); }
			catch (Exception ex) { LogSafety($"Client enumeration failed: {ex.GetType().Name}"); return; }
			_incompatiblePids.RemoveWhere(pid => !newClients.ContainsKey(pid));
			_warnedPids.RemoveWhere(pid => !newClients.ContainsKey(pid));
			checkBoxContainer.Children.OfType<CheckBox>()
				.Where(cb => !TryGetClientId(cb.Content?.ToString(), out int pid) || !newClients.ContainsKey(pid))
				.ToList().ForEach(cb => checkBoxContainer.Children.Remove(cb));

			foreach (var client in newClients.Values)
			{
				if (!IsClientListed(client) && !string.IsNullOrWhiteSpace(client.name))
				{
					AddClientCheckBox(client);
				}
			}

			ActiveClients = checkBoxContainer.Children.OfType<CheckBox>()
				.Where(cb => cb.IsChecked == true)
				.Where(cb => TryGetClientId(cb.Content?.ToString(), out int pid) && !_incompatiblePids.Contains(pid))
				.Select(cb => new ClientInfo { name = GetClientName(cb.Content?.ToString() ?? ""), id = GetClientId(cb.Content?.ToString() ?? "") })
				.ToList();
		}

		public void ExecuteScript(string script)
		{
			if (string.IsNullOrWhiteSpace(script) || ActiveClients.Count == 0) return;
			if (DateTime.UtcNow - _lastExecution < ExecutionCooldown)
			{
				LogSafety("Repeated execution suppressed by cooldown.");
				return;
			}
			_lastExecution = DateTime.UtcNow;
			var clientUsers = ActiveClients.Where(c => !_incompatiblePids.Contains(c.id)).Select(c => c.name).Distinct().ToArray();
			if (clientUsers.Length == 0) return;
			try { Execute(Encoding.UTF8.GetBytes(script + "\0"), clientUsers, clientUsers.Length); }
			catch (Exception ex) { LogSafety($"Execution failed: {ex.GetType().Name}"); MessageBox.Show("Execution failed; see diagnostic output.", "Galo", MessageBoxButton.OK, MessageBoxImage.Warning); }
		}

		public string GetCompilableStatus(string script)
		{
			IntPtr resultPtr = Compilable(Encoding.UTF8.GetBytes(script + "\0"));
			string result = Marshal.PtrToStringUTF8(resultPtr) ?? string.Empty;
			if (resultPtr != IntPtr.Zero) Marshal.FreeCoTaskMem(resultPtr);
			return result;
		}

		private List<ClientInfo> GetClientsFromDll()
		{
			var clients = new List<ClientInfo>();
			IntPtr currentPtr = GetClients();
			if (currentPtr == IntPtr.Zero) return clients;
			while (true)
			{
				var client = Marshal.PtrToStructure<ClientInfo>(currentPtr);
				if (client.name == null) break;
				clients.Add(client);
				currentPtr += Marshal.SizeOf<ClientInfo>();
			}
			return clients;
		}

		private static bool TryGetClientId(string? content, out int id)
		{
			id = 0;
			if (string.IsNullOrWhiteSpace(content)) return false;
			int split = content.LastIndexOf(", PID: ", StringComparison.Ordinal);
			return split >= 0 && int.TryParse(content[(split + 7)..], out id) && id > 0;
		}
		private static int GetClientId(string content) => TryGetClientId(content, out int id) ? id : 0;
		private static string GetClientName(string content) => content.Split(", PID: ")[0].Trim();
		private bool IsClientListed(ClientInfo client) => checkBoxContainer.Children.OfType<CheckBox>().Any(cb => cb.Content.ToString() == $"{client.name}, PID: {client.id}");

		private void AddClientCheckBox(ClientInfo client)
		{
			if (client.name == "N/A")
			{
				return;
			}
			checkBoxContainer.Children.Add(new CheckBox
			{
				Content = $"{client.name}, PID: {client.id}",
				Foreground = Brushes.White,
				FontFamily = new FontFamily("Franklin Gothic Medium"),
				IsChecked = SupportedVersion == client.version,
				IsEnabled = SupportedVersion == client.version,
				Background = Brushes.Black
			});
			if (SupportedVersion != client.version)
			{
				_incompatiblePids.Add(client.id);
				if (_warnedPids.Add(client.id))
					MessageBox.Show($"Client {client.name} ({client.id}) reports version {client.version}.\n\nExpected version: {SupportedVersion}\n\nExecution is disabled for this client until compatibility is verified.", "Unsupported Client Version", MessageBoxButton.OK, MessageBoxImage.Warning);
			}
		}

		private void buttonClose_Click(object sender, RoutedEventArgs e) => Hide();
	}
}
